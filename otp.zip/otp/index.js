const express = require('express')
const nodemailer = require('nodemailer');
const otpGenerator = require('otp-generator');



const app = express();

const port = 3000;

const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'joeljonahsz@gmail.com',
        pass: 'renitarhea'
    }
})

const otpMap = new Map();

app.get('/send-otp', (req, res) => {
    const userEmail = req.query.email;

    if (!userEmail) {
        return res.status(400).send('Email required')
    }

    // function generateNumericOTP(length) {
    //     const digits = '0123456789';
    //     let OTP = '';
      
    //     for (let i = 0; i < length; i++) {
    //       const index = Math.floor(Math.random() * 10);
    //       OTP += digits[index];
    //     }
      
    //     return OTP;
    //   }
      
    //   const otp = generateNumericOTP(6); 
    //   console.log(otp);
  
      
    const otp = otpGenerator.generate(6, { digits: true, alphabets: false, specialChars: false});
    console.log(otp);


    otpMap.set(userEmail, otp);

    const mailOptions = {
        from: 'joelonahsz@gmail.com',
        to: userEmail,
        subject: 'otp for email verification',
        text: `your otp for email verification is: ${otp}`
    }

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return res.status(500).send(`failed to send error ${error}`)

        }
        else {
            res.send('Otp send succesfully');
        };
    });


})
app.get('/verify-otp', (req, res) => {
    const userEmail = req.query.email;
    const userOTP = req.query.otp;

    if (!userEmail || !userOTP) {
        return res.status(400).send('Email and OTP are required');
    }

    const storedOTP = otpMap.get(userEmail);

    if (storedOTP === userOTP) {
        // OTP is valid
        otpMap.delete(userEmail); // Remove the OTP from storage (or set it as used in a database)
        res.send('OTP is valid. Email verified.');
    } else {
        res.status(403).send('Invalid OTP');
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

